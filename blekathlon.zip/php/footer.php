<footer class="site-footer main-padding text-center smaller-font-size">
    <div class="site-info main-width">
        <div class="text-center text-white text-uppercase">
            <?php echo $site->footer(); ?>
            <span class="sep"> | </span>
            <span>
                Powered by <a target="_blank" class="text-white" href="https://www.bludit.com">Bludit</a> &amp; <a target="_blank" class="text-white" href="https://blthemes.pp.ua">Blekathlon</a>
            </span>
        </div>
    </div>
</footer>
<script>
	var uploadsFolder = '<?php echo HTML_PATH_UPLOADS; ?>';
</script>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">

<?php echo Theme::headTitle(); ?>
<?php echo $helper->head_description(); ?>

<?php echo Theme::favicon('img/favicon.ico'); ?>
<?php echo Theme::css('css/style.min.css'); ?>
<?php Theme::plugins('siteHead'); ?>
